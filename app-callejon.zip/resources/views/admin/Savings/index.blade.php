@extends('layouts.app')
@section('body-class','product-page')
@section('title','Reserva de la Registradora (admin)')
@section('content')
    <div class="page-header header-filter" data-parallax="true" filter-color="rose" style="background-image: url('../assets/img/bg6.jpg');">
        <div class="container">
            <div class="row title-row" style="visibility: hidden">
                <div class="col-md-4 col-md-offset-8">
                    <a href="{{ url('/admin/savings/create') }}" class="btn btn-white pull-right"><i class="material-icons">shopping_cart</i> 0 Items</a>
                </div>
            </div>
        </div>
    </div>
    <div class="section section-gray">
        <div class="container">
            <div class="main main-raised main-product">
                <div class="row">
                    <div class="tab-content">
                        <div class="row">
                            <div class="col-md-3">
                                <ul class="nav nav-pills nav-pills-icons nav-stacked" role="tablist">
                                    <!--
                                        color-classes: "nav-pills-primary", "nav-pills-info", "nav-pills-success", "nav-pills-warning","nav-pills-danger"
                                    -->
                                    <li >
                                        <a href="#dashboard-2" role="tab" data-toggle="tab">
                                            <i class="material-icons">change_circle</i>
                                            Cambiar Cantidad
                                        </a>
                                    </li>
                                    <li class="active">
                                        <a href="#schedule-2" role="tab" data-toggle="tab">
                                            <i class="material-icons">hourglass_full</i>
                                            Historial de Cantidades
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-8">
                                <div class="tab-content">
                                    <div class="tab-pane" id="dashboard-2">
                                        <div class="container">
                                            @include('includes.savings_modify')
                                        </div>
                                    </div>
                                    <div class="tab-pane active" id="schedule-2">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                <tr>
                                                    <th>Cantidad</th>
                                                    <th>Autorizo</th>
                                                    <th>Fecha</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                @foreach($savings as $saving)
{{--                                                    @dd($saving)--}}
                                                    <tr>
{{--                                                        Consulta normal--}}
                                                        <td>{{ $saving->cantidad }}</td>
                                                        <td>{{ $saving->guardo }}</td>
                                                        <td>{{ $saving->guardado }}</td>
                                                    </tr>
                                                @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('includes.footer')
@endsection
