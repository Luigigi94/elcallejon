@extends('layouts.app')
@section('body-class','profile-page sidebar-collapse')
@section('title','Listado de Prodctos')
@section('content')
    <div class="page-header header-filter" data-parallax="true" style="background-image: url('{{asset('img/profile_city.jpg')}}')">

    </div>
    <div class="main main-raised">
        <div class="container">
            <div class="section text-center">
                <h2 class="title">Listado de Productos Disponibles</h2>
                <div class="team">
                    <div align="right">
                        <a href="{{url('/admin/products/create')}}" class="btn btn-success btn-round">
                            <i class="material-icons">add_circle_outline</i> Agregar
                        </a>
                    </div>
                    <div class="row">
                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Categoria</th>
                                <th class="text-right">Precio</th>
                                <th class="text-right">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
{{--                            probando los joins--}}
{{--                            @foreach($categories as $ca)--}}
{{--                                <table class="table">--}}
{{--                                    <tr>--}}
{{--                                        <td><h4>{{ $ca->name }}</h4></td>--}}
{{--                                    </tr>--}}
{{--                                </table>--}}
{{--                            @endforeach--}}
                            @foreach($products as $product)
{{--                                @dd($product)--}}
                            <tr>
                                <td class="text-center">{{ $product->id }}</td>
                                <td>{{ $product->name }}</td>
                                <td class="col-md-4">{{ $product->description }}</td>
                                <td>{{ $product->category ? $product->category->name: 'General' }}</td>
                                <td class="text-right">&dollar;{{$product->price}}</td>
                                <td class="td-actions text-right">
                                    <form method="post" action="{{ url('admin/boards/'.$product->id) }}">
                                        {{ csrf_field() }}
                                        {{ method_field('DELETE') }}

                                        <a href="#something" class="btn btn-info btn-fab btn-round" rel="tooltip" title="Ver info">
                                            <i class="material-icons">info</i>
                                        </a>
                                        <a href="{{ url('admin/products/'.$product->id.'/edit') }}" class="btn btn-success btn-fab btn-round" rel="tooltip" title="Modificar Producto">
                                            <i class="material-icons">edit</i>
                                        </a>
                                        <button class="btn btn-danger btn-fab btn-fab btn-round" rel="tooltip" title="Eliminar Producto" type="submit">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table>
                        <div>
                            {{$products->links()}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@include('includes.footer')
@endsection

