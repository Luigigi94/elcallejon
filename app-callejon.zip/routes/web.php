<?php

use App\Models\Product;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TestController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','TestController@index');

//Route::get('/admin/products','ProductController@index');//listado
//Route::get('/admin/products/create','ProductController@create');//crear productos
//Route::post('/admin/products/','ProductController@store');//guardar productos

Route::middleware(['admin'])->prefix('admin')->group(function () {
    //Productos
    Route::get('/products', 'ProductController@index')->name('index');//listado
    Route::get('/products/create','ProductController@create');//crear productos
    Route::post('/products/','ProductController@store');//guardar productos
    Route::get('/products/{id}/edit','ProductController@edit');//edit productos
    Route::post('/products/{id}/edit','ProductController@update');//edit productos
    Route::delete('/products/{id}','ProductController@destroy');//form eliminar
    //Usuarios
    Route::get('/users','UserController@index')->name('index');
    Route::get('/users/create','UserController@create')->name('create');
    Route::post('users','UserController@store')->name('save');
    Route::get('/users/{id}/edit','UserController@edit');//edit productos
    Route::post('/users/{id}/edit','UserController@update');//edit productos
    Route::delete('/users/{id}','UserController@destroy');//form eliminar
    //Mesas
    Route::get('/boards','BoardController@index')->name('index');
    Route::get('/boards/create','BoardController@create');
    Route::post('/boards','BoardController@store');
    Route::get('/boards/{id}/edit','BoardController@edit');
    Route::post('/boards/{id}/edit','BoardController@update');
    Route::delete('/boards/{id}','BoardController@destroy');

    //Ahorros
    Route::get('/savings','SavingsController@index')->name('index');
    Route::get('/savings/create','savingsController@create');
    Route::post('/savings','savingsController@store');
    Route::get('/savings/{id}/edit','savingsController@edit');
    Route::post('/savings/{id}/edit','savingsController@update');
    Route::delete('/savings/{id}','savingsController@destroy');

    //Caja registradora
    Route::get('/tills','TillController@index')->name('index');
    Route::get('/tills/create','TillController@create');
    Route::post('/tills','TillController@store');
    Route::get('/tills/{id}/edit','TillController@edit');
    Route::post('/tills/{id}/edit','TillController@update');
    Route::delete('/tills/{id}','TillController@destroy');




});

//Route::prefix('admin')->group(function () {
//    Route::get('/admin/products', 'ProductController@index');//listado
//    Route::get('/admin/products/create','ProductController@create');//crear productos
//    Route::post('/admin/products/','ProductController@store');//guardar productos
//    Route::get('/admin/products/{id}/edit','ProductController@edit');//edit productos
//    Route::post('/admin/products/{id}/edit','ProductController@update');//edit productos
//    Route::delete('/admin/products/{id}','ProductController@destroy');//form eliminar
//
//});



Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
