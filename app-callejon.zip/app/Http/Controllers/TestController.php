<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TestController extends Controller
{
    public function index()
    {
        $products = Product::all();

//        $data =\DB::table('organizador')
//            ->join('unidades', 'organizador.unidad', '=', 'unidades.id')
//            ->select('unidades.unidad', 'organizador.columnaElegida')
//            ->get();
//        SELECT `product_images`.`image` FROM `product_images` INNER JOIN `products` ON `product_images`.`product_id` = `products`.`id`;
        $images = DB::table('products')
            ->join('product_images','products.id','=','product_images.product_id')
            ->join('categories','categories.id','=','products.category_id')
            ->select('product_images.*','products.*','categories.*')
            ->first();
//            ->get();
        return view('welcome')->with(compact('products'))/*->with(compact('images'))*/;

//        @dd('messagen');
    }
}
