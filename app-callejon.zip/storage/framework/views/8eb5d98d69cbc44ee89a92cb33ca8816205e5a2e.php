<?php $__env->startSection('body-class','profile-page sidebar-collapse'); ?>
<?php $__env->startSection('title','Listado de Prodctos'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header header-filter" data-parallax="true" style="background-image: url('<?php echo e(asset('img/profile_city.jpg')); ?>')">

    </div>
    <div class="main main-raised">
        <div class="container">
            <div class="section text-center">
                <h2 class="title">Listado de Productos Disponibles</h2>
                <div class="team">
                    <div align="right">
                        <a href="<?php echo e(url('/admin/products/create')); ?>" class="btn btn-success btn-round">
                            <i class="material-icons">add_circle_outline</i> Agregar
                        </a>
                    </div>
                    <div class="row">
                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Categoria</th>
                                <th class="text-right">Precio</th>
                                <th class="text-right">Actions</th>
                            </tr>
                            </thead>
                            <tbody>








                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="text-center"><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->name); ?></td>
                                <td class="col-md-4"><?php echo e($product->description); ?></td>
                                <td><?php echo e($product->category ? $product->category->name: 'General'); ?></td>
                                <td class="text-right">&dollar;<?php echo e($product->price); ?></td>
                                <td class="td-actions text-right">
                                    <form method="post" action="<?php echo e(url('admin/products/'.$product->id)); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>


                                        <button class="btn btn-info btn-fab btn-round" rel="tooltip" title="Ver info">
                                            <i class="material-icons">info</i>
                                        </button>
                                        <a href="<?php echo e(url('admin/products/'.$product->id.'/edit')); ?>" class="btn btn-success btn-fab btn-round" rel="tooltip" title="Modificar Producto">
                                            <i class="material-icons">edit</i>
                                        </a>
                                        <button class="btn btn-danger btn-fab btn-fab btn-round" rel="tooltip" title="Eliminar Producto" type="submit">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div>
                            <?php echo e($products->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/admin/products/index.blade.php ENDPATH**/ ?>