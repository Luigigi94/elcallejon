<?php $__env->startSection('body-class','profile-page'); ?>
<?php $__env->startSection('title','Usuarios de '.auth()->user()->name); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-header header-filter" data-parallax="true" style="background-image: url('<?php echo e(asset('img/examples/city.jpg')); ?>');"></div>
    <div class="main main-raised">
        <div class="profile-content">
            <div class="container">
                <div class="row">
                    <div class="col-xs-6 col-xs-offset-3">
                        <div class="profile">
                            <div class="avatar">
                                <img src="<?php echo e(asset('img/img.jpg')); ?>" alt="Circle Image" class="img-circle img-responsive img-raised">
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-2 follow">
                        <a href="<?php echo e(url('/admin/users/create')); ?>" class="btn btn-fab btn-primary" rel="tooltip" title="Agregar Usuarios">
                            <i class="material-icons">add</i>
                        </a>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr>

                            <th>Nombre</th>
                            <th>Fecha de Contratación</th>
                            <th>Administrador</th>
                            <th class="text-right">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->created_at); ?></td>

                                <td><?php if(($user->admin) == 1): ?>admin <?php else: ?> Empleado <?php endif; ?> </td>
                                <td class="td-actions text-right">
                                    <form action="<?php echo e(url('/admin/users/'.$user->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <a href="#something" type="button" rel="tooltip" class="btn btn-info" data-placement="left" title="Ver">
                                            <i class="material-icons">person</i>
                                        </a>
                                        <a href="<?php echo e(url('/admin/users/'.$user->id.'/edit')); ?>" type="button" rel="tooltip" class="btn btn-success" data-placement="left" title="Editar">
                                            <i class="material-icons">edit</i>
                                        </a>
                                        <button type="submit" rel="tooltip" class="btn btn-danger" data-placement="left" title="Eliminar">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/admin/users/index.blade.php ENDPATH**/ ?>