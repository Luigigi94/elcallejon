<div class="section">
    <h4 class="title text-center">Cambiar Guardadito</h4>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($errors); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(url('/admin/savings/')); ?>">
        <?php echo e(csrf_field()); ?>


        <div class="row">
            <div class="col-sm-6">
                <div class="form-group bmd-form-group">
                    <label class="bmd-label-floating">cantidad</label>
                    <input type="number" class="form-control" name="quantity" value="<?php echo e(old('quantity')); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3">

                <button type="submit" class="btn btn-primary">Submit</button>

            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/includes/savings_modify.blade.php ENDPATH**/ ?>