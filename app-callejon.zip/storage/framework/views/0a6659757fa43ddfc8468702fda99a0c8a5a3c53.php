<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />


    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title><?php echo $__env->yieldContent('title','El Callejon'); ?></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />

    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />

    <!-- CSS Files -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/material-kit.css')); ?>" rel="stylesheet" />
</head>

<body class="<?php echo $__env->yieldContent('body-class'); ?>">
<nav class="navbar navbar-dark navbar-absolute navbar-fixed-top navbar-color-on-scroll">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example">
            		<span class="sr-only">Toggle navigation
					.</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <?php if(auth()->user()): ?>
                <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                    <?php echo e(config('app.name')); ?> </a>
            <?php else: ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name')); ?> </a>
            <?php endif; ?>
        </div>

        <div class="collpase navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><i class="material-icons">account_circle</i><?php echo e(__('Ingresar')); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><i class="material-icons">person_add</i><?php echo e(__('Registro')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Cerrar Sesión')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="material-icons">account_box</i>                             <?php echo e(Auth::user()->name); ?>

                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-with-icons">
                            <li>
                                <a href="<?php echo e(url('/admin/savings')); ?>">
                                    <i class="material-icons">attach_money</i> Reserva Caja Registradora
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/admin/boards')); ?>">
                                    <i class="material-icons">coffee</i> Mesas
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/admin/tills')); ?>">
                                    <i class="material-icons">local_grocery_store</i> Caja Registradora
                                </a>
                            </li>






























                            <li>
                                <a href="<?php echo e(url('/admin/users')); ?>">
                                    <i class="material-icons">account_circle</i> Usuarios
                                </a>
                            </li>
                            <li>

                            </li>
                        </ul>
                    </li>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php echo $__env->yieldContent('content'); ?>

</body>
<!--   Core JS Files   -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/material.min.js')); ?>"></script>

<!--    Plugin for Date Time Picker and Full Calendar Plugin   -->
<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>

<!--	Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/   -->
<script src="<?php echo e(asset('js/nouislider.min.js')); ?>" type="text/javascript"></script>

<!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker   -->
<script src="<?php echo e(asset('js/bootstrap-datetimepicker.js')); ?>" type="text/javascript"></script>

<!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select   -->
<script src="<?php echo e(asset('js/bootstrap-selectpicker.js')); ?>" type="text/javascript"></script>

<!--	Plugin for Tags, full documentation here: http://xoxco.com/projects/code/tagsinput/   -->
<script src="<?php echo e(asset('js/bootstrap-tagsinput.js')); ?>"></script>

<!--	Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput   -->
<script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>

<!--    Plugin For Google Maps   -->


<!--    Control Center for Material Kit: activating the ripples, parallax effects, scripts from the example pages etc    -->
<script src="<?php echo e(asset('js/material-kit.js')); ?>" type="text/javascript"></script>
</html>
<?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/layouts/app.blade.php ENDPATH**/ ?>