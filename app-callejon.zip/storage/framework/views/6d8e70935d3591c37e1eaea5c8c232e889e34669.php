<?php $__env->startSection('body-class','profile-page sidebar-collapse'); ?>
<?php $__env->startSection('title','Editar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header header-filter" data-parallax="true" style="background-image: url('<?php echo e(asset('img/profile_city.jpg')); ?>')">
    </div>
    <div class="main main-raised">
        <div class="container">
            <div class="section">
                <h2 class="title text-center">Editar <?php echo e($product->name); ?></h2>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($errors); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?php echo e(url('/admin/products/'.$product->id.'/edit')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group bmd-form-group">
                                <label class="bmd-label-floating">Nombre</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $product->name)); ?>">
                            </div></div>
                        <div class="col-sm-6">
                            <div class="form-group bmd-form-group">
                                <label class="bmd-label-floating">Precio del Producto</label>
                                <input type="number" class="form-control" name="price" value="<?php echo e(old('price',$product->price)); ?>" step=".01">
                            </div>
                        </div>
                    </div>
                    <div class="form-group bmd-form-group">
                        <label class="bmd-label-floating">Descripcion</label>
                        <input type="text" class="form-control" name="description" value="<?php echo e(old('description',$product->description)); ?>">
                    </div>
                    <textarea class="form-control" placeholder="Escribe aqui la descripción" rows="5"name="long_description"><?php echo e(old('long_description',$product->long_description)); ?></textarea>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Cancel</a>
                </form>
            </div>
        </div>
    </div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>