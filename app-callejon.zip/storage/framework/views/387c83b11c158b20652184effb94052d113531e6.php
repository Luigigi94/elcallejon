<?php $__env->startSection('body-class','profile-page'); ?>
<?php $__env->startSection('title','Editar Mesas'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header header-filter header-small" data-parallax="true" style="background-image: url('<?php echo e(asset('/img/bg2.jpg')); ?>');">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <h1 class="title">Administración de las Mesas</h1>
                    <h4>Aqui puedes ver, editar y modificar lo relacionado a las mesas</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="main main-raised">
        <div class="container">
            <div class="section">
                <h2 class="title text-center">Registrar</h2>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($errors); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form method="post" action="<?php echo e(url('/admin/boards/')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group bmd-form-group">
                                <label class="bmd-label-floating">Numero de Mesa</label>
                                <input type="Number" class="form-control" name="num_board" value="<?php echo e(old('num_board',$board->num_board)); ?>">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group bmd-form-group">
                                <label class="bmd-label-floating">Lugar</label>
                                <input type="text" class="form-control" name="place" value="<?php echo e(old('place',$board->place)); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/admin/boards/edit.blade.php ENDPATH**/ ?>