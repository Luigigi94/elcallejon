<?php $__env->startSection('body-class','pricing'); ?>
<?php $__env->startSection('title','Mesas (Admin)'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header header-filter header-small" data-parallax="true" style="background-image: url('<?php echo e(asset('/img/bg2.jpg')); ?>');">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <h1 class="title">Administración de las Mesas</h1>
                    <h4>Aqui puedes ver, editar y modificar lo relacionado a las mesas</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="main main-raised">
        <div class="container">
            <div class="pricing-2">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 text-center">
                        <ul class="nav nav-pills nav-pills-rose" role="tablist" style="visibility: hidden">
                            <li class="active">
                                <a href="#dashboard-1" role="tab" data-toggle="tab">
                                    Monthly
                                </a>
                            </li>
                            <li>
                                <a href="#schedule-1" role="tab" data-toggle="tab">
                                    Yearly
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($bor->id)%2 ): ?>
                            <div class="col-md-6">
                                <div class="card card-pricing card-plain">
                                    <div class="card-content">
                                        <h6 class="category text-info"></h6>
                                        <h1 class="card-title"><?php echo e($bor->num_board); ?></h1>
                                        <ul>
                                            <li><?php echo e($bor->place); ?></li>
                                        </ul>
                                        <div class="row">
                                            <div class="col-md-3 col-md-offset-2">
                                                <a href='<?php echo e(url('/admin/boards/'.$bor->id.'/edit')); ?>' class="btn btn-rose btn-raised btn-round">
                                                    Editar Mesa
                                                </a>
                                            </div>
                                            <div class="col-md-3 col-md-offset-1">
                                                <form method="post" action="<?php echo e(url('admin/boards/'.$bor->id)); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <button class="btn btn-rose btn-raised btn-round" type="submit">
                                                        Eiminar mesa
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                        <div class="col-md-6">
                            <div class="card card-pricing card-plain">
                                <div class="card-content content-rose">
                                    <h6 class="category text-info"></h6>
                                    <h1 class="card-title"><?php echo e($bor->num_board); ?></h1>
                                    <ul>
                                        <li><?php echo e($bor->place); ?></li>
                                    </ul>
                                    <div class="row">
                                        <div class="col-md-3 col-md-offset-2">
                                            <a href='<?php echo e(url('/admin/boards/'.$bor->id.'/edit')); ?>' class="btn btn-white btn-raised btn-round">
                                        Editar Mesa
                                    </a>
                                        </div>
                                        <div class="col-md-3 col-md-offset-1">
                                            <form method="post" action="<?php echo e(url('admin/boards/'.$bor->id)); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <button class="btn btn-white btn-raised btn-round" type="submit">
                                                    Eiminar mesa
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($board->links()); ?>

            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/admin/boards/index.blade.php ENDPATH**/ ?>