    <div class="container">
        <div class="section">
            <h2 class="title text-center">Registrar</h2>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($errors); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(url('/admin/products/')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group bmd-form-group">
                            <label class="bmd-label-floating">Nombre</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                        </div></div>
                    <div class="col-sm-4">
                        <div class="form-group bmd-form-group">
                            <label class="bmd-label-floating">Precio del Producto</label>
                            <input type="number" class="form-control" name="price" step=".01" value="<?php echo e(old('price')); ?>">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group bmd-form-group">
                            <div class="container d-flex justify-content-center align-items-center">

                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group bmd-form-group">
                    <label class="bmd-label-floating">Descripcion</label>
                    <input type="text" class="form-control" name="description" value="<?php echo e(old('description')); ?>">
                </div>
                <textarea class="form-control" placeholder="Escribe aqui la descripción" rows="5"name="long_description" value="<?php echo e(old('long_description')); ?>"></textarea>
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Cancel</a>

            </form>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/includes/creates.blade.php ENDPATH**/ ?>