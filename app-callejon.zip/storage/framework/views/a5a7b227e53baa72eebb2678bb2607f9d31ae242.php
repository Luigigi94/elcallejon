<?php $__env->startSection('body-class','profile-page'); ?>
<?php $__env->startSection('title','Crear Usuario'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header header-filter" data-parallax="true" style="background-image: url('<?php echo e(asset('img/profile_city.jpg')); ?>')">
    </div>
    <div class="main main-raised">
        <div class="container">
            <div class="section">
                <h2 class="title text-center">Registrar</h2>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($errors); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form method="post" action="<?php echo e(url('/admin/users/')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group bmd-form-group">
                                <label class="bmd-label-floating">Nombre</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group bmd-form-group">
                                <label class="bmd-label-floating">Email</label>
                                <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3">
                            <div class="form-group bmd-form-group">
                                <label class="bmd-label-floating">Contraseña</label>
                                <input type="password" class="form-control" name="password" value="<?php echo e(old(bcrypt('password'))); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3">
                            <input type="text" name="admin" value="2" style="visibility: hidden">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/admin/users/create.blade.php ENDPATH**/ ?>