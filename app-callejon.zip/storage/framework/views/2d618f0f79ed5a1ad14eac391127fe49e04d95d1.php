<?php $__env->startSection('body-class','product-page'); ?>
<?php $__env->startSection('title','Reserva de la Registradora (admin)'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header header-filter" data-parallax="true" filter-color="rose" style="background-image: url('../assets/img/bg6.jpg');">
        <div class="container" style="visibility: hidden">
            <div class="row title-row">
                <div class="col-md-4 col-md-offset-8">
                    <a href="<?php echo e(url('/admin/savings/create')); ?>" class="btn btn-white pull-right"><i class="material-icons">shopping_cart</i> 0 Items</a>
                </div>
            </div>
        </div>
    </div>
    <div class="section section-gray">
        <div class="container">
            <div class="main main-raised main-product">
                <div class="container">
                    <div class="section">
                        <h2 class="title text-center">Registrar</h2>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($errors); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form method="post" action="<?php echo e(url('/admin/savings/')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group bmd-form-group">
                                        <label class="bmd-label-floating">cantidad</label>
                                        <input type="number" class="form-control" name="quantity" value="<?php echo e(old('quantity')); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-sm-offset-3">

                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/admin/Savings/create.blade.php ENDPATH**/ ?>