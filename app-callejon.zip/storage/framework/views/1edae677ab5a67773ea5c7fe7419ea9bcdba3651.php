<?php $__env->startSection('body-class','product-page'); ?>
<?php $__env->startSection('title','Reserva de la Registradora (admin)'); ?>
<?php $__env->startSection('content'); ?>

    <div class="features-5" style="background-image: url('<?php echo e(asset('/img/bg9.jpg')); ?>')">

        <div class="col-md-8 col-md-offset-2 text-center">
            <h2 class="title">Your life will be much easier</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="info">
                        <div class="icon">
                            <i class="material-icons">code</i>
                        </div>
                        <h4 class="info-title">For Developers</h4>
                        <p>The moment you use Material Kit, you know you’ve never felt anything like it. With a single use, this powerfull UI Kit lets you do more than ever before. </p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="info">
                        <div class="icon">
                            <i class="material-icons">format_paint</i>
                        </div>
                        <h4 class="info-title">For Designers</h4>
                        <p>The moment you use Material Kit, you know you’ve never felt anything like it. With a single use, this powerfull UI Kit lets you do more than ever before. </p>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="info">
                        <div class="icon">
                            <i class="material-icons">dashboard</i>
                        </div>
                        <h4 class="info-title">Bootstrap Grid</h4>
                        <p>The moment you use Material Kit, you know you’ve never felt anything like it. With a single use, this powerfull UI Kit lets you do more than ever before. </p>
                    </div>
                </div>

            </div>

        </div>
    </div>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\app-callejon\resources\views/admin/till/index.blade.php ENDPATH**/ ?>